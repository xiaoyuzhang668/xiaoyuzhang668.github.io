<?php

/*
Plugin Name:  Image Display Style 1
Version: 1.0
Description: Display image in hover carousel.
Author: Cathy Zhang
Author URI: 
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: /languages
*/
/**
 * input of 3 images
 * @return image carousel
*/

function cz_enqueue_scripts() {
 global $post;    
     $has_shortcode = has_shortcode( $post->post_content, 'cz_image_style_1' ) || has_shortcode( $post->post_content, 'box' );
    
 if( (is_a( $post, 'WP_Post' ) || is_a( $page, 'WP_Page' ) )&& has_shortcode( $post->post_content, 'cz_image_style_1') ) {
 wp_register_style( 'cz-stylesheet',  plugin_dir_url( __FILE__ ) . 'css/style.css' );
     wp_enqueue_style( 'cz-stylesheet' );
 }
}
add_action( 'wp_enqueue_scripts', 'cz_enqueue_scripts');


/**
 * [box] returns the HTML code for a content 
 * @return string HTML code for boxed content
*/

add_shortcode( 'cz_image_style_1', 'style_1' );

function style_1( ) {
    
    $output = '<div class="container-cz">';
    
   for ( $i=1; $i <= 5; $i++) {
       
    $id = get_theme_mod('video_poster'.$i); 
         $output .= '<div alt="missing content" class="box-cz"><img class="w-100 img-fluid" src="'.wp_get_attachment_url($id).'"><span>'.get_theme_mod('video_header'.$i).'</span></div>';     
            
      
//   .plugin_dir_url( __FILE__ ) . 'images/sample.png"   
    
   }  
    return $output;
}


function video_frontpage_theme_customizer( $wp_customize ) {
        //  Video Section
$wp_customize->add_panel('videosection_panel', array(
        'priority'       => 200,
        'theme_supports' => '',
        'title'          => __( '1. Video Section (Front Page)', 'framework' ),
        'description'    => __( 'Set editable text for certain content.', 'framework' ),
    ));
for ( $i=1; $i <= 5; $i++) {	
    $wp_customize->add_section( 'video_panel'.$i , array(
        'title'    => __('Video '.$i ,'framework'),
        'panel'    => 'videosection_panel',  
        'priority' => 130
    ) ); 	
		$wp_customize->add_setting( 'video_upload_'.$i,
			 array(
					'default' 					=> '',
					'transport' 				=> 'refresh',
					'sanitize_callback' => 'absint',
					'type' 							=> 'theme_mod',
			 )
		);
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'video_upload_'.$i,
			 array(
					'label' 				=> __( 'Default Media Control' ),
					'description' 	=> esc_html__( 'Video on front page' ),
					'section' 			=> 'video_panel'.$i, 
					'settings' 			=> 'video_upload_'.$i,
					'priority' 			=> 1,
					'mime_type' 		=> 'video',  // Required. Can be image, audio, video, application, text
					'button_labels' => array( // Optional
					 'select' 			=> __( 'Select Video' ),
					 'change' 			=> __( 'Change Video' ),
					 'default' 			=> __( 'Default' ),
					 'remove' 			=> __( 'Remove Video' ),
					 'placeholder' 	=> __( 'No video selected' ),
					 'frame_title' 	=> __( 'Select File' ),
					 'frame_button' => __( 'Choose File' ),
					)
			 )
		) );
		    //add poster image
    $wp_customize->add_setting('video_poster'.$i,  array(
            'default' 					=> get_bloginfo('template_directory').'/images/customizer/default.jpg',
						'transport' 				=> 'refresh',
            'type' 							=> 'theme_mod', 
        ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'video_poster'.$i, array(
            'label' => __('Poster image for Video', 'framework'),
						'height'        		=> 40, 
						'width'        			=> 70,
						'flex_width' => true,
						'flex_height' => true,
            'section' 					=> 'video_panel'.$i, 
            'settings' 					=> 'video_poster'.$i, 
            'priority' 					=> 1
        )));
	 	 // Add header setting
    $wp_customize->add_setting( 'video_header'.$i, array(
         'default' 	=> __( 'header', 'framework' ),
         'type' 		=> 'theme_mod'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'video_header'.$i,
            array(
                'label'    => __( 'Header', 'framework' ),
                'section'  => 'video_panel'.$i,
                'settings' => 'video_header'.$i,
                'priority' => 1,
                'type'     => 'text'
            )
        )
    );
}
}
add_action( 'customize_register', 'video_frontpage_theme_customizer' );

add_shortcode( 'current_year', 'cz_year' );
 function cz_year() {
 return "<div class='ml-1'>".getdate()['year']."</div>";
 }

add_action('init', 'cz_year');
