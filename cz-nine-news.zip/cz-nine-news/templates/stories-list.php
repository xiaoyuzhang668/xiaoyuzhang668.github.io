<?php
$settings       = get_option('abc_news_settings');
$open_new_tab   = isset($settings['open_new_tab']) ? $settings['open_new_tab'] : true;
$show_source    = isset($settings['show_source']) ? $settings['show_source'] : true;
$show_images    = isset($settings['show_images']) ? $settings['show_images'] : true;
$target         = $open_new_tab ? ' target="_blank" rel="noopener noreferrer"' : '';

// Get the feed URL (either from widget instance or settings)
$feed_url = isset($feed_url) ? $feed_url : (isset($settings['feed_url']) ? $settings['feed_url'] : 'https://abcnews.go.com/abcnews/topstories');

// Determine source name based on feed URL
$source_name = 'News'; // Default
if (strpos($feed_url, 'bbc.com') !== false) {
    $source_name = 'BBC News';
} elseif (strpos($feed_url, 'nbcnews.com') !== false) {
    $source_name = 'NBC News';
} elseif (strpos($feed_url, 'cnn.com') !== false) {
    $source_name = 'CNN';
} elseif (strpos($feed_url, 'reuters.com') !== false) {
    $source_name = 'Reuters';
} elseif (strpos($feed_url, 'xinhuanet.com') !== false) {
    $source_name = 'Xinhua News';
} elseif (strpos($feed_url, 'nytimes.com') !== false) {
    $source_name = 'New York Times';
} elseif (strpos($feed_url, 'theguardian.com') !== false) {
    $source_name = 'The Guardian';
} elseif (strpos($feed_url, 'newyorker.com') !== false) {
    $source_name = 'Ner Yorker';
} elseif (strpos($feed_url, 'scmp.com') !== false) {
    $source_name = 'South China Morning Post';
}
// Add more sources as needed
?>
<div class="abc-news-stories">
    <h2 class="abc-news-source-header"><?php echo esc_html($source_name); ?> Top Stories</h2>
    
    <?php foreach ($stories as $story): ?>
        <div class="abc-news-story">
            <?php if ($show_images && !empty($story['image'])): ?>
                <div class="abc-news-image">
                    <a href="<?php echo $story['url']; ?>"<?php echo $target; ?>>
                        <img src="<?php echo $story['image']; ?>" alt="<?php echo esc_attr($story['title']); ?>" onerror="this.style.display='none'" />
                    </a>
                </div>
            <?php elseif ($show_images): ?>
                <div class="abc-news-image-placeholder">
                    <a href="<?php echo $story['url']; ?>"<?php echo $target; ?>>
                        <div class="abc-news-no-image">No Image Available</div>
                    </a>
                </div>
            <?php endif; ?>
            <div class="abc-news-content">
                <h3 class="abc-news-title">
                    <a href="<?php echo $story['url']; ?>"<?php echo $target; ?>><?php echo $story['title']; ?></a>
                </h3>
                <div class="abc-news-meta">
                    <span class="abc-news-date"><?php echo $story['published']; ?></span>
                </div>
                <?php if (!empty($story['description'])): ?>
                    <div class="abc-news-description"><?php echo $story['description']; ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>