<?php
/*
Plugin Name: CZ 9 Nine - ABC News Top Stories
Plugin URI: https://www.cathyzhang.ca/sample/abc-top-news/
Description: Displays the latest top stories from ABC News (abcnews.go.com) on your WordPress site using RSS feed.
Version: 1.1
Author: Cathy Zhang
Author URI: https://www.cathyzhang.ca
License: GPL2
*/

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/abc-news-feed.php';
require_once plugin_dir_path(__FILE__) . 'includes/abc-news-widget.php';
require_once plugin_dir_path(__FILE__) . 'includes/abc-news-settings.php';

// Register activation hook
register_activation_hook(__FILE__, 'abc_news_activate');

function abc_news_activate() {
    // Set default options if they don't exist
    if (false === get_option('abc_news_settings')) {
        $defaults = array(
            'feed_url' => 'https://abcnews.go.com/abcnews/topstories',
            'num_stories' => 5,
            'cache_duration' => 3600,
            'show_images' => true,
            'open_new_tab' => true,
            'show_source' => true
        );
        add_option('abc_news_settings', $defaults);
    }
}

// Enqueue styles
add_action('wp_enqueue_scripts', 'abc_news_enqueue_styles');

function abc_news_enqueue_styles() {
    wp_enqueue_style(
        'abc-news-styles',
        plugin_dir_url(__FILE__) . 'assets/css/abc-news-styles.css',
        array(),
        '1.1'
    );
}

// Register shortcode
add_shortcode('abc_news_top_stories', 'abc_news_shortcode_handler');

function abc_news_shortcode_handler($atts) {
    $settings = get_option('abc_news_settings');
    $num_stories = isset($settings['num_stories']) ? $settings['num_stories'] : 5;
    
    $atts = shortcode_atts(array(
        'count' => $num_stories,
        'show_images' => isset($settings['show_images']) ? $settings['show_images'] : true,
        'feed_url' => isset($settings['feed_url']) ? $settings['feed_url'] : 'https://abcnews.go.com/abcnews/topstories'
    ), $atts);
    
    $stories = abc_news_fetch_stories($atts['feed_url'], $atts['count']);
    
    if (is_wp_error($stories)) {
        return '<p class="abc-news-error">Error loading News stories. Please try again later.</p>';
    }
    
    ob_start();
    include plugin_dir_path(__FILE__) . 'templates/stories-list.php';
    return ob_get_clean();
}

// Register widget
add_action('widgets_init', 'abc_news_register_widget');

function abc_news_register_widget() {
    register_widget('ABC_News_Widget');
}