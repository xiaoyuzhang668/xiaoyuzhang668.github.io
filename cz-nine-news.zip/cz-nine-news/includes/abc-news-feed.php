<?php
if (!defined('ABSPATH')) {
    exit;
}

function abc_news_fetch_stories($feed_url, $count = 5) {
    $settings = get_option('abc_news_settings');
    $cache_key = 'abc_news_feed_' . md5($feed_url) . '_' . $count;
    $stories = get_transient($cache_key);
    
    // If cached data exists and is valid, return it
    if (false !== $stories) {
        return $stories;
    }
    
    // Include WordPress feed functions
    include_once(ABSPATH . WPINC . '/feed.php');
    
    // Fetch the feed
    $rss = fetch_feed($feed_url);
    
    if (is_wp_error($rss)) {
        return $rss;
    }
    
    // Get specified number of items
    $maxitems = $rss->get_item_quantity($count);
    $rss_items = $rss->get_items(0, $maxitems);
    
    $stories = array();
    
    foreach ($rss_items as $item) {
        $description = $item->get_description();
        $image = '';
        
        // First try to get media:thumbnail (RSS 2.0 with Media RSS)
        if ($enclosure = $item->get_enclosure()) {
            if ($enclosure->get_thumbnail()) {
                $image = esc_url($enclosure->get_thumbnail());
            } elseif ($enclosure->get_link()) {
                $image = esc_url($enclosure->get_link());
            }
        }
        
        // If no media thumbnail, try to extract from description
        if (empty($image)) {
            if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"]/i', $description, $matches)) {
                $image = esc_url($matches[1]);
                // Remove image from description
                $description = preg_replace('/<img[^>]+\>/i', '', $description);
            }
        }
        
        // If still no image, try to get it from content:encoded
        if (empty($image) && method_exists($item, 'get_content')) {
            $content = $item->get_content();
            if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"]/i', $content, $content_matches)) {
                $image = esc_url($content_matches[1]);
            }
        }
        
        // Detect source based on feed URL
        $source = 'ABC News'; // default
        if (strpos($feed_url, 'bbc.com') !== false) {
            $source = 'BBC News';
        } elseif (strpos($feed_url, 'nbcnews.com') !== false) {
            $source = 'NBC News';
        } elseif (strpos($feed_url, 'cnn.com') !== false) {
            $source = 'CNN';
        } elseif (strpos($feed_url, 'reuters.com') !== false) {
            $source = 'Reuters';
        } elseif (strpos($feed_url, 'xinhuanet.com') !== false) {
            $source = 'Xinhua News';
        } elseif (strpos($feed_url, 'scmp.com') !== false) {
            $source = 'South China Morning Post';
        }
        
        $stories[] = array(
            'title' => sanitize_text_field($item->get_title()),
            'url' => esc_url($item->get_permalink()),
            'description' => wp_kses_post($description),
            'published' => $item->get_date('M j, Y g:i a'),
            'image' => $image,
            'source' => $source // Use the detected source
        );
    }
    
    // Cache the results
    $cache_duration = isset($settings['cache_duration']) ? $settings['cache_duration'] : 3600;
    set_transient($cache_key, $stories, $cache_duration);
    
    return $stories;
}