<?php
if (!defined('ABSPATH')) {
    exit;
}

class ABC_News_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'abc_news_widget',
            'News Top Stories',
            array('description' => 'Displays the latest top stories from News using RSS feed.')
        );
    }
    
    public function widget($args, $instance) {
        $settings = get_option('abc_news_settings');
        
        $stories = abc_news_fetch_stories($feed_url, $count);
    
        // Get the source from the first story
        $source = !empty($stories[0]['source']) ? $stories[0]['source'] : 'News';
        
        // Modify the title to include the source if it's not already there
        $title = apply_filters('widget_title', empty($instance['title']) ? $source . ' Top Stories' : $instance['title']);
    
        $count = empty($instance['count']) ? 5 : absint($instance['count']);
        $show_images = isset($instance['show_images']) ? (bool) $instance['show_images'] : true;
        $feed_url = empty($instance['feed_url']) ? 
            (isset($settings['feed_url']) ? $settings['feed_url'] : 'https://abcnews.go.com/abcnews/topstories') : 
            $instance['feed_url'];
        
        // Make sure show_images is passed to the template
        $GLOBALS['abc_news_show_images'] = $show_images;
        
        echo $args['before_widget'];
        
        if ($title) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $stories = abc_news_fetch_stories($feed_url, $count);
        
        if (is_wp_error($stories)) {
            echo '<p class="abc-news-error">Error loading News stories. Please try again later.</p>';
        } else {
            include plugin_dir_path(__FILE__) . '../templates/stories-list.php';
        }
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $settings = get_option('abc_news_settings');
        $title = isset($instance['title']) ? esc_attr($instance['title']) : 'News Top Stories';
        $count = isset($instance['count']) ? absint($instance['count']) : 5;
        $show_images = isset($instance['show_images']) ? (bool) $instance['show_images'] : true;
        $feed_url = isset($instance['feed_url']) ? esc_url($instance['feed_url']) : 
            (isset($settings['feed_url']) ? $settings['feed_url'] : 'https://abcnews.go.com/abcnews/topstories');
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('feed_url'); ?>">RSS Feed URL:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('feed_url'); ?>" name="<?php echo $this->get_field_name('feed_url'); ?>" type="text" value="<?php echo $feed_url; ?>" />
            <small>Default: https://abcnews.go.com/abcnews/topstories</small>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('count'); ?>">Number of stories to show:</label>
            <input id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" type="number" min="1" max="20" value="<?php echo $count; ?>" />
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_images); ?> id="<?php echo $this->get_field_id('show_images'); ?>" name="<?php echo $this->get_field_name('show_images'); ?>" />
            <label for="<?php echo $this->get_field_id('show_images'); ?>">Show thumbnails</label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['count'] = absint($new_instance['count']);
        $instance['show_images'] = isset($new_instance['show_images']) ? (bool) $new_instance['show_images'] : false;
        $instance['feed_url'] = esc_url_raw($new_instance['feed_url']);
        return $instance;
    }
}