<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'abc_news_add_admin_menu');
add_action('admin_init', 'abc_news_settings_init');

function abc_news_add_admin_menu() {
    add_options_page(
        'ABC News Settings',
        'ABC News',
        'manage_options',
        'abc-news-settings',
        'abc_news_settings_page'
    );
}

function abc_news_settings_init() {
    register_setting('abc_news', 'abc_news_settings');
    
    add_settings_section(
        'abc_news_general_section',
        'Feed Settings',
        'abc_news_general_section_callback',
        'abc_news'
    );
    
    add_settings_field(
        'feed_url',
        'RSS Feed URL',
        'abc_news_feed_url_render',
        'abc_news',
        'abc_news_general_section'
    );
    
    add_settings_field(
        'num_stories',
        'Default Number of Stories',
        'abc_news_num_stories_render',
        'abc_news',
        'abc_news_general_section'
    );
    
    add_settings_field(
        'cache_duration',
        'Cache Duration (seconds)',
        'abc_news_cache_duration_render',
        'abc_news',
        'abc_news_general_section'
    );
    
    add_settings_section(
        'abc_news_display_section',
        'Display Settings',
        'abc_news_display_section_callback',
        'abc_news'
    );
    
    add_settings_field(
        'show_images',
        'Show Thumbnail Images',
        'abc_news_show_images_render',
        'abc_news',
        'abc_news_display_section'
    );
    
    add_settings_field(
        'open_new_tab',
        'Open Links in New Tab',
        'abc_news_open_new_tab_render',
        'abc_news',
        'abc_news_display_section'
    );
    
    add_settings_field(
        'show_source',
        'Show Source Attribution',
        'abc_news_show_source_render',
        'abc_news',
        'abc_news_display_section'
    );
}

function abc_news_feed_url_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="text" class="regular-text" name="abc_news_settings[feed_url]" value="<?php echo isset($options['feed_url']) ? esc_url($options['feed_url']) : 'https://abcnews.go.com/abcnews/topstories'; ?>" />
    <p class="description">Default: https://abcnews.go.com/abcnews/topstories</p>
    <?php
}

function abc_news_num_stories_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="number" min="1" max="20" name="abc_news_settings[num_stories]" value="<?php echo isset($options['num_stories']) ? $options['num_stories'] : 5; ?>" />
    <?php
}

function abc_news_cache_duration_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="number" min="300" step="300" name="abc_news_settings[cache_duration]" value="<?php echo isset($options['cache_duration']) ? $options['cache_duration'] : 3600; ?>" />
    <p class="description">How long to cache stories before fetching new ones (default: 3600 = 1 hour)</p>
    <?php
}

function abc_news_show_images_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="checkbox" name="abc_news_settings[show_images]" <?php checked(isset($options['show_images']) ? $options['show_images'] : true, true); ?> value="1" />
    <?php
}

function abc_news_open_new_tab_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="checkbox" name="abc_news_settings[open_new_tab]" <?php checked(isset($options['open_new_tab']) ? $options['open_new_tab'] : true, true); ?> value="1" />
    <?php
}

function abc_news_show_source_render() {
    $options = get_option('abc_news_settings');
    ?>
    <input type="checkbox" name="abc_news_settings[show_source]" <?php checked(isset($options['show_source']) ? $options['show_source'] : true, true); ?> value="1" />
    <?php
}

function abc_news_general_section_callback() {
    echo '<p>Configure the RSS feed source and caching settings.</p>';
}

function abc_news_display_section_callback() {
    echo '<p>Configure how stories are displayed on your site.</p>';
}

function abc_news_settings_page() {
    ?>
    <div class="wrap">
        <h1>ABC News Settings</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('abc_news');
            do_settings_sections('abc_news');
            submit_button();
            ?>
        </form>
        
        <div class="abc-news-feed-test">
            <h2>Feed Test</h2>
            <p>Test the current feed settings:</p>
            <?php
            $options = get_option('abc_news_settings');
            $feed_url = isset($options['feed_url']) ? $options['feed_url'] : 'https://abcnews.go.com/abcnews/topstories';
            $test_stories = abc_news_fetch_stories($feed_url, 1);
            
            if (is_wp_error($test_stories)) {
                echo '<div class="notice notice-error"><p>Error: ' . esc_html($test_stories->get_error_message()) . '</p></div>';
            } elseif (empty($test_stories)) {
                echo '<div class="notice notice-warning"><p>No stories found in the feed.</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>Feed is working correctly. Last story title: "' . esc_html($test_stories[0]['title']) . '"</p></div>';
            }
            ?>
        </div>
    </div>
    <?php
}